//
//  inf1100_a2_har009.c
//  
//
//  Created by Harald on 10/14/14.
//
//

#include <stdio.h>
#include <stdlib.h>

void task5(void)
{
    int i;
    
/* for er bygd opp på følgende måte:
 for (initialization; condition; iteration_step)
 {
    body;
 }
 
 while er bygd opp på følgende måte:
 condition;
 while (condition)
 {
    body;
    iteration_step;
 }
    
*/
    // Oppgave 5a
    i = 0;
    while (i < 5)
    {
        printf("%d\n", i);
        i = i + 1;
    }
    
    // Oppgave 5b
    i = 0;
    while (i < 5)
    {
        printf("%d\n", i);
        i++;
    }

    // Oppgave 5c
    i = 5;
    while (i >= 0)
    {
        printf("%d\n", i);
        i = i - 1;
    }
    
    // Oppgave 5d
    /*
    i = 0;
    while (i <= 5)
    {
        printf("%d\n", i);
        i *= 2;
    }
    */
}

// Task 6
int multiply_by_five(int n)
{
    return n * 5;
}

// Task 7
void mynumbers(void)
{
    int i;
    
    for (i = 1; i <= 50; i++)
    {
        printf("%d is ", i);
        if (i % 2 == 0)
            printf("even ");
        else
            printf("odd ");
        
        printf("and 5 is ");
        
        if (i % 5 != 0)
            printf("not ");
        
        printf("a prime factor\n");
    }
}

// Task 8
void mytriangles(int numlines)
{
    int i, j;
    
    for (i = 1; i <= numlines; i++)
    {
        for (j = 0; j < i; j++)
        {
            printf("*");
        }
        printf("\n");
    }
}

// Task 9
void celsius_vs_fahrenheit(void)
{
    int celsius;
    float fahrenheit;
    
    for (celsius = 0; celsius <= 50; celsius++)
    {
        fahrenheit = 9.0/5.0 * (float)celsius + 32;
        printf("%d degrees celsius converts to %.1f fahrenheit\n", celsius, fahrenheit);
    }
}

// Task 10
void reverse_integer(void)
{
    int n = 0;
    
    printf("Skriv inn et tall for reversering: ");
    scanf("%d", &n);
    printf("Tallet %d vil bli reversert\n", n);
    
    while (n > 0)
    {
        printf("%d", n % 10);
        n = n / 10;
    }
    printf("\n");
}

// Task 11
int mylog2(unsigned int n)
{
    int counter = 0;
    while (n > 1)
    {
        n = n >> 1;
        counter++;
    }
    
    return counter;
}

int main(int argc, char *argv[])
{
    int resval;
    //task5();
    resval = multiply_by_five(5);
    printf("resultatet av 5 * 5 er: %d\n", resval);
    mynumbers();
    mytriangles(5);
    celsius_vs_fahrenheit();
    reverse_integer();
    resval = mylog2(17);
    printf("En tilnærming av log2(17) er: %d\n", resval);
    
    return EXIT_SUCCESS;
    
}