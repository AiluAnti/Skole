#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <assert.h>
#include "SDL.h"
#include "drawline.h"

// Define an "alias" for the data structure describing a wheel
// The alias allows you to refer to the data structure by writing
// wheel_t instead of struct wheel.
typedef struct wheel wheel_t;

// Define a data structure describing a wheel
struct wheel {
    int         x;
    int         y;
    float       spokedistance;
    int         hub_radius;
    int         rim_radius;
    float       angle;
};


// Create and initialize a description of a wheel
// Note the use of named field initialization.
wheel_t somewheel = {
	.x 		= 200,
	.y 		= 200,
	.spokedistance	= 15.0,
	.hub_radius	= 10,
	.rim_radius 	= 100,
        .angle          = 0.0,
};


// Clear screen by filling it with 0
void ClearScreen(SDL_Surface *screen)
{
    SDL_Rect rect;
    
    // Define a rectangle covering the entire screen
    rect.x = 0;
    rect.y = 0;
    rect.w = screen->w;
    rect.h = screen->h;
    
    // And fill screen with 0
    SDL_FillRect(screen, &rect, 0);
}


// Draw wheel by drawing lines between points on hub and rim arc
void DrawWheel(SDL_Surface *screen, wheel_t *wheel)
{
	float angle;
	int i, numspokes;
	int hubx, huby, rimx, rimy;
	int phubx, phuby, primx, primy;

	phubx = phuby = primx = primy = -1;
	angle = wheel->angle;
	numspokes = 360.0/wheel->spokedistance + 1;
	for (i = 0; i < numspokes; i++) {
		// Calculate hub and rim coordinates
		hubx = wheel->x + wheel->hub_radius*cosf(angle*(M_PI/180.0));
		huby = wheel->y + wheel->hub_radius*sinf(angle*(M_PI/180.0));
		rimx = wheel->x + wheel->rim_radius*cosf(angle*(M_PI/180.0));
		rimy = wheel->y + wheel->rim_radius*sinf(angle*(M_PI/180.0));
		
		// Draw
		if (phubx != -1) {
			// Draw hub line
			DrawLine(screen, phubx, phuby, hubx, huby, SDL_MapRGB(screen->format, 0xff, 0, 0));

			// Draw rim line
			DrawLine(screen, primx, primy, rimx, rimy, SDL_MapRGB(screen->format, 0xff, 0, 0));
			
			// Draw wheel spoke
			DrawLine(screen, hubx, huby, rimx, rimy, SDL_MapRGB(screen->format, 0xff, 0, 0));
		}
		
		// Store coordinates
		phubx = hubx;
		phuby = huby;
		primx = rimx;
		primy = rimy;
		
		// Next spoke
		angle += wheel->spokedistance;		
	}	
}


void Demo(SDL_Surface *screen)
{
	unsigned int	time, rtime;
	SDL_Event 		event;

	while (1) {
		// Get current time
		time = SDL_GetTicks();
	
		// Clear screen
		ClearScreen(screen);
	
		// Draw wheel
		DrawWheel(screen, &somewheel);
		
		// Force screen update
		SDL_UpdateRect(screen, 0, 0, screen->w, screen->h);

		// Calculate rendering time
		rtime = SDL_GetTicks() - time;
		
		// Animate
		somewheel.angle += (50.0*rtime)/1000.0;
		if (somewheel.angle > 360.0)
			somewheel.angle -= 360.0;

		// Check for ctrl-c
		SDL_PollEvent(&event);
		if (event.type == SDL_QUIT)
			break;
			
	}
}


int main(int argc, char **argv)
{
	int retval;
	SDL_Surface *screen;

	// Initialize SDL
	retval = SDL_Init(SDL_INIT_VIDEO);
	if (retval == -1) {
		printf("Unable to initialize SDL\n");
		exit(1);
	}

	//Create a 1024x768x32 window
	screen = SDL_SetVideoMode(1024, 768, 32, 0);
	if (screen == NULL) {
		printf("Unable to get video surface: %s\n", SDL_GetError());
		exit(1);
	}
			
	Demo(screen);

	SDL_Quit();

	return 0;
}
