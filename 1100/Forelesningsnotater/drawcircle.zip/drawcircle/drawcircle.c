#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <assert.h>
#include "SDL.h"

// Define an "alias" for the data structure describing a circle
// The alias allows you to refer to the data structure by writing
// cirle_t instead of struct circle.
typedef struct circle circle_t;

// Define a data structure describing a circle
struct circle {
    int x;
    int y;
    int radius;
};


// Create and initialize an array describing some circles.
// Note the use of named field initialization.
circle_t somecircles[] = {
	{	.x 		= 100,
		.y 		= 100,
		.radius	= 10,
	},
	{	.x 		= 150,
		.y 		= 100,
		.radius = 50,
	},
	{	.x 		= 220,
		.y 		= 220,
		.radius = 40,
	}
};



// Set pixel x,y on the screen
void SetPixel(SDL_Surface *screen, int x, int y, unsigned int color)
{
    unsigned int *bufp;

    // Check if pixel is outside of screen
    if (x >= screen->w ||  x < 0 ||
        y >=screen->h || y < 0) {
         printf("Accessing pixel outside of screen, check translation or scale\n");
         return 0;
    }

    // Set pixel
    bufp = (unsigned int*)screen->pixels + y*screen->pitch/4 + x;
    *bufp = color;	

    // Force screen update
    SDL_UpdateRect(screen, x, y, 1, 1); 	
}

// Draw a line on the screen from x1,y1 to x2,y2
void DrawLine(SDL_Surface *screen, int x1, int y1, int x2, int y2, unsigned int color)
{
    int fraction;
    int x, dx, stepx;
    int y, dy, stepy;
    
    // The below code implements the classic Bresenham algorithm
    
    dx = x2 - x1;
    dy  = y2 - y1;
    	
    if (dy < 0) {
        dy = -dy;
        stepy = -1;
    } else {
        stepy = 1;	
    }
    
    if (dx < 0) {
        dx = -dx;
        stepx = -1;	
    } else {
        stepx = 1;
    }
    
    dy = dy*2;
    dx = dx*2;
    x = x1;
    y = y1;
    SetPixel(screen, x, y, color);
    if (dx > dy) {
        fraction = dy - (dx/2);
        while (x != x2) {
            if (fraction >= 0) {
                y = y + stepy;
                fraction = fraction - dx;	
            }
            x = x + stepx;
            fraction = fraction + dy;
            SetPixel(screen, x, y, color);
        }	
    } else {
        fraction = dx - (dy/2);
        while (y != y2) {
            if (fraction >= 0) {
                x = x + stepx;
                fraction = fraction - dy;	
            }
            y = y + stepy;
            fraction = fraction + dx;
            SetPixel(screen, x, y, color);
        }	
    }
}


// Draw circle by drawing a line between coordinates on the circle arc
void DrawCircleLine(SDL_Surface *screen, circle_t *circle)
{
	float angle;
    int x, y;
	int px, py;

	// Note: 
	// This code can be used to draw polygons by changing the angle step.
	// 120 degrees between each step equals a triangle
	// 90 degrees a square
	// etc.
	
	// From the unity circle
	//       /|
	//      / |
	//	C /   | A
	//   /    |
	//  /_X___|
	//     B
	// sinX = A/C = A/1 = A (y coordinate)
	// cosX = B/C = B/1 = B (x coordinate)
	// => Given an angle (X), multiply by radius and add origin coordinate to get
	//    the coordinate of a specific point on the circle arc.
	// (x,y) = (x + radius*cosX, y + radius*sinX)
	px = py = -1;
	angle = 0.0;
	while (angle <= 360.0) {
		// Note that sinf and cosf operates in radians (hence the M_PI/180.0 calculation).
		// Think carefully about the below calculation in terms of data types (cosf and sinf return a float):
		// int + int*cosf(float*(float/float) = int + int*float = int + float = float
		// int + int*sinf(float*(float/float) = int + int*float = int + float = float
		// If arithmetic involves a float, integers are converted to floats before the calculation is done.
		// But what about int = float or int = float (x = float, y = float)?
		// In C, assignment will always convert the right side to the type of the left side.
		x = circle->x + circle->radius*cosf(angle*(M_PI/180.0));
		y = circle->y + circle->radius*sinf(angle*(M_PI/180.0));
		
		// Draw line between previous and current arc coordinates.  Skip first loop iteration.
		if (px != -1) {
			DrawLine(screen, px, py, x, y, SDL_MapRGB(screen->format, 0xff, 0, 0));
		}

		// Store coordinates
		px = x;
		py = y;
		
		// Next circle coordinate
		angle += 60.0;
	}	
	
}


// Draw circle by setting pixels on circle arc
void DrawCircle(SDL_Surface *screen, circle_t *circle)
{
	float angle;
    int x, y;

	// From the unity circle
	//       /|
	//      / |
	//	C /   | A
	//   /    |
	//  /_X___|
	//     B
	// sinX = A/C = A/1 = A (y coordinate)
	// cosX = B/C = B/1 = B (x coordinate)
	// => Given an angle (X), multiply by radius and add origin coordinate to get
	//    the coordinate of a specific point on the circle arc.
	// (x,y) = (x + radius*cosX, y + radius*sinX)
	angle = 0.0;
	while (angle < 360.0) {
		// Note that sinf and cosf operates in radians (hence the M_PI/180.0 calculation).
		// Think carefully about the below calculation in terms of data types (cosf and sinf return a float):
		// int + int*cosf(float*(float/float) = int + int*float = int + float = float
		// int + int*sinf(float*(float/float) = int + int*float = int + float = float
		// If arithmetic involves a float, integers are converted to floats before the calculation is done.
		// But what about int = float or int = float (x = float, y = float)?
		// In C, assignment will always convert the right side to the type of the left side.
		x = circle->x + circle->radius*cosf(angle*(M_PI/180.0));
		y = circle->y + circle->radius*sinf(angle*(M_PI/180.0));
		
		// Draw on screen
		SetPixel(screen, x, y, SDL_MapRGB(screen->format, 0xff, 0, 0));
		
		// Next circle coordinate
		angle += 1.0;
	}	
	
}



int main(int argc, char **argv)
{
    int i, retval, done;
    SDL_Surface *screen;
    SDL_Event event;
    
    // Initialize SDL   
    retval = SDL_Init(SDL_INIT_VIDEO);
    if (retval == -1) {
        printf("Unable to initialize SDL\n");
        exit(1);    
    }
    
    //Create a 1024x768x32 window
    screen = SDL_SetVideoMode(1024, 768, 32, 0);     
    if (screen == NULL) {
        printf("Unable to get video surface: %s\n", SDL_GetError());    
        exit(1);
    }

	// Draw circles
	for (i = 0; i < 3; i++) {
		DrawCircle(screen, &somecircles[i]);
		//DrawCircleLine(screen, &somecircles[i]);
	}
		
    // Wait for ctrl-c from user
    done = 0;
    while (done == 0) {
        while (SDL_PollEvent(&event)) {
            switch (event.type) {
            case SDL_QUIT:
                done = 1;
                break;  
            }           
        }
    }   
    
    SDL_Quit();
    
    return 0;
}
