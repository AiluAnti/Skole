#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <assert.h>
#include "SDL.h"
#include "drawline.h"
#include "textscroll.h"

// Clear screen by filling it with 0
void ClearScreen(SDL_Surface *screen)
{
    SDL_Rect rect;
    
    // Define a rectangle covering the entire screen
    rect.x = 0;
    rect.y = 0;
    rect.w = screen->w;
    rect.h = screen->h;
    
    // And fill screen with 0
    SDL_FillRect(screen, &rect, 0);
}


void Demo(SDL_Surface *screen)
{
    unsigned int	time, rtime;
    SDL_Event 		event;
    float		numsteps;
    textscroll_t	*textscroll;
    textscroll_t	*textscroll2;

    // Create text scroller
    textscroll = textscroll_create(screen, 100, 100, 50, 500, 2.0, "DETTE ER EN TEXT SCROLLER");
    textscroll2 = textscroll_create(screen, 200, 200, 25, 200, 1.0, "OG ENDA EN TEXT SCROLLER");
	
    numsteps = 1.0;
    while (1) {
    	// Get current time
     	time = SDL_GetTicks();
    
    	// Clear screen
    	ClearScreen(screen);
    
     	// Draw text scroller
        textscroll_draw(textscroll, numsteps);
        textscroll_draw(textscroll2, numsteps);
		
        // Force screen update
        SDL_UpdateRect(screen, 0, 0, screen->w, screen->h);

        // Calculate rendering time
        rtime = SDL_GetTicks() - time;

        // Calculate # animation steps in next frame
        numsteps = (50.0*rtime)/1000.0;

        // Check for ctrl-c
        SDL_PollEvent(&event);
        if (event.type == SDL_QUIT)
            break;
    }
    textscroll_destroy(textscroll);
    textscroll_destroy(textscroll2);
}


int main(int argc, char **argv)
{
    int retval;
    SDL_Surface *screen;
    
    // Initialize SDL   
    retval = SDL_Init(SDL_INIT_VIDEO);
    if (retval == -1) {
        printf("Unable to initialize SDL\n");
        exit(1);    
    }
    
    //Create a 1024x768x32 window
    screen = SDL_SetVideoMode(1024, 768, 32, 0);     
    if (screen == NULL) {
        printf("Unable to get video surface: %s\n", SDL_GetError());    
        exit(1);
    }

    // Show effects
    Demo(screen);
    
    // Quit SDL
    SDL_Quit();
    
    return 0;
}
