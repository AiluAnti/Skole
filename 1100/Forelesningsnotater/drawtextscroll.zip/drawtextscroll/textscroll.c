#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "SDL.h"
#include "drawline.h"
#include "hershey_font.h"
#include "textscroll.h"

#define MIN(x, y) ((x) < (y) ? (x) : (y))

struct textscroll {
    SDL_Surface	*screen;	
    int         sx, sy;         // Screen scroll box x,y position
    int         sh, sw;         // Screen scroll box height and width	
    float       scrollspeed;    // Scroll speed
    SDL_Surface	*textsurface;   // SDL surface containing pre-drawn scroll-text
    float       drawxpos;       // Draw position in textsurface
};


// Calculate width of text in pixels
static int calctextwidth(char *text, float scale)
{
    int i;
    int c;
    int width;

    width = 0;
    for (i = 0; text[i] != 0; i++) {
        // Skip unknown characters
        if (text[i] < ' ' || text[i] > '~') {
            continue;
        }
        c = text[i] - ' ';
        width += ceil(scale*font[c].spacing);
    }
    return width;
}


// Draw text inside box
static void drawtext(SDL_Surface *textsurface, float scale, int sx, int sh, char *text)
{
    int         i;
    int         c;
    int         x1, y1, x2, y2;
    int         numvertices;
    vertex_t    *vertices;
	
    for (i = 0; text[i] != 0; i++) {
        // Skip unknown characters
        if (text[i] < ' ' || text[i] > '~') {
            text++;
            continue;
        }
			
        // Draw character
        c = text[i] - ' ';
        numvertices = font[c].numvertices;
        vertices = font[c].vertices;
        while (numvertices > 0) {
            x1 = vertices->x;
            y1 = vertices->y;
			
            // Next vertex
            numvertices--;
            vertices++;
			
            x2 = vertices->x;
            y2 = vertices->y;

            // Pen up?
            if (x2 == -1 && y2 == -1) {
                numvertices--;
                vertices++;
                continue;
            }
			
            // Scale
            x1 = x1*scale;
            y1 = y1*scale;
            x2 = x2*scale;
            y2 = y2*scale;

            // Draw line
            DrawLine(textsurface, 
                     x1 + sx,           // x1
                     -y1 + (sh-1),      // y1
                     x2 + sx,           // x2
                     -y2 + (sh-1),      // y2
                     SDL_MapRGB(textsurface->format, 0xff, 0xff, 0xff));
        }
	
        // Move horizontally (space between characters)
        sx = sx + ceil(font[c].spacing * scale);
    }
}


// Create new text scroller
textscroll_t *textscroll_create(SDL_Surface *screen, int screenx, int screeny, int screenheight, int screenwidth, float scrollspeed, char *text)
{
    textscroll_t        *textscroll;
    float               scale;

    // New text scroller
    textscroll = malloc(sizeof(textscroll_t));
    if (textscroll == NULL)
        goto error;
    textscroll->screen = screen;
    textscroll->sx = screenx;
    textscroll->sy = screeny;
    textscroll->sh = screenheight;
    textscroll->sw = screenwidth;
    textscroll->scrollspeed = scrollspeed;
    textscroll->drawxpos = 0.0;
		
    // Calculate scaling factor. The font is 25 pixels high
    scale = screenheight/25.0;

    // Create text surface
    textscroll->textsurface = SDL_CreateRGBSurface(SDL_SWSURFACE, 
                                                   calctextwidth(text, scale) + textscroll->sw, // Width
                                                   textscroll->sh,                              // Height
                                                   32, 0, 0, 0, 0);
    if (textscroll->textsurface == NULL)
        goto error;
	
    // Draw text inside text surface
    drawtext(textscroll->textsurface, scale, textscroll->sw, textscroll->sh, text);

    return textscroll;
error:
    if (textscroll != NULL)
        free(textscroll);
    return NULL;
}


// Draw text scroller
void textscroll_draw(textscroll_t *textscroll, float numsteps)
{
    SDL_Rect 	drect;
    SDL_Rect 	srect;

    // Update where to start copying from text surface
    textscroll->drawxpos += textscroll->scrollspeed*numsteps;

    // If end of text surface, start drawing from beginning
    if (textscroll->drawxpos >= textscroll->textsurface->w)
        textscroll->drawxpos = 0.0;
	
    // Copy surface to screen
    srect.x = textscroll->drawxpos;
    srect.y = 0;
    srect.h = textscroll->sh;
    srect.w = MIN(textscroll->sw, textscroll->textsurface->w - srect.x);

    drect.x = textscroll->sx;
    drect.y = textscroll->sy;
    drect.h = srect.h;
    drect.w = srect.w;
	
    SDL_BlitSurface(textscroll->textsurface, &srect, textscroll->screen, &drect);
}


// Free text scroller resources
void textscroll_destroy(textscroll_t *textscroll)
{
    // Free SDL surface
    SDL_FreeSurface(textscroll->textsurface);

    // Free data structure
    free(textscroll);
}
