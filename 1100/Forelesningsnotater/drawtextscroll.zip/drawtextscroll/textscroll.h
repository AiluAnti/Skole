#ifndef TEXTSCROLL_H_
#define TEXTSCROLL_H_

struct textscroll;
typedef struct textscroll textscroll_t;

textscroll_t *textscroll_create(SDL_Surface *screen, int screenx, int screeny, int screenheight, int screenwidth, float scrollspeed, char *text);
void textscroll_draw(textscroll_t *textscroll, float numsteps);
void textscroll_destroy(textscroll_t *textscroll);


#endif /* TEXTSCROLL_H_ */
