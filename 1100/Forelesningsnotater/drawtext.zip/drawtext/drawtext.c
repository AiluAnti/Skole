#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <assert.h>
#include "SDL.h"
#include "drawline.h"
#include "hershey_font.h"


void DrawText(SDL_Surface *screen, int sx, int sy, char *text)
{
	int			c;
	int 		x1, y1, x2, y2;
	int 		numvertices;
	vertex_t	*vertices;

	// Draw text
	while (*text != 0) {
		// Skip unknown characters
        if (*text < ' ' || *text > '~') {
            text++;
			continue;
        }
			
		// Draw character
		c = *text - ' ';
		numvertices = font[c].numvertices;
		vertices = font[c].vertices;
		while (numvertices > 0) {
			x1 = vertices->x;
			y1 = vertices->y;
			
			// Next vertex
			numvertices--;
			vertices++;
			
			x2 = vertices->x;
			y2 = vertices->y;

			// Pen up?
			if (x2 == -1 && y2 == -1) {
				numvertices--;
				vertices++;
				continue;
			}
			
			DrawLine(screen, x1 + sx, -y1 + sy, x2 + sx, -y2 + sy, SDL_MapRGB(screen->format, 0xff, 0xff, 0xff));
		}

		// Move horizontally (space between characters)
		sx = sx + font[c].spacing;
		
		// Next character
		text++;
	}
	
	// Make sure the text is visible on the screen
	SDL_UpdateRect(screen, 0, 0, screen->w, screen->h);
}



int main(int argc, char **argv)
{
    int retval, done;
    SDL_Surface *screen;
    SDL_Event event;
    
    // Initialize SDL   
    retval = SDL_Init(SDL_INIT_VIDEO);
    if (retval == -1) {
        printf("Unable to initialize SDL\n");
        exit(1);    
    }
    
    //Create a 1024x768x32 window
    screen = SDL_SetVideoMode(1024, 768, 32, 0);     
    if (screen == NULL) {
        printf("Unable to get video surface: %s\n", SDL_GetError());    
        exit(1);
    }

	DrawText(screen, 250, 250, "DETTE ER EN TEST!!!");
		
    // Wait for ctrl-c from user
    done = 0;
    while (done == 0) {
        while (SDL_PollEvent(&event)) {
            switch (event.type) {
            case SDL_QUIT:
                done = 1;
                break;  
            }           
        }
    }   
    
    SDL_Quit();
    
    return 0;
}
