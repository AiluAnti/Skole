#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <assert.h>
#include "SDL.h"
#include "drawline.h"


void CreateWaveTable(int *table, int numsteps, int amplitude)
{
	int i;
	float sinestep;

	sinestep = (2*M_PI)/numsteps;
	for (i = 0; i < numsteps; i++) {
		table[i] = sinf(sinestep*i)*amplitude;
	}
}


void DrawSineCurve(SDL_Surface *screen, int amplitude)
{
	int x, wavetablesize;
	int wavetable[512];

	// Create table with sine coordinates
	wavetablesize = 128;
	CreateWaveTable(wavetable, wavetablesize, amplitude);
	
	// Draw line in middle of sine curve
	DrawLine(screen, 0, amplitude, screen->w-1, amplitude, SDL_MapRGB(screen->format, 0xff, 0xff, 0xff)); 
	
	// Draw sine curve
	for (x = 0; x < screen->w; x++) {
		// Force update of entire screen.
		// NOTE: The pixels in the window on the screen are represented by a buffer (array) in memory.
		//       When we set the color of a pixel, we are really just writing a value to the
		//       buffer position corresponding to the pixel position in the window.
		//       The SDL call under reads the contents of the buffer and makes
		//       sure the pixels are visible on the screen.
		SDL_UpdateRect(screen, 0, 0, screen->w, screen->h);

		// Draw
		// NOTE: We reverse the sign of the y coordinate to get an actual sine curve.
		//       Position 0,0 in the window is in the upper left corner and the positive
		//       y axis is downwards..
		SetPixel(screen, x, -wavetable[x % wavetablesize] + amplitude, SDL_MapRGB(screen->format, 0xff, 0xff, 0xff));
		
		// Wait 5ms
		SDL_Delay(5);
	}
}

int main(int argc, char **argv)
{
    int retval, done;
    SDL_Surface *screen;
    SDL_Event event;
    
    // Initialize SDL   
    retval = SDL_Init(SDL_INIT_VIDEO);
    if (retval == -1) {
        printf("Unable to initialize SDL\n");
        exit(1);    
    }
    
    //Create a 1024x768x32 window
    screen = SDL_SetVideoMode(1024, 768, 32, 0);     
    if (screen == NULL) {
        printf("Unable to get video surface: %s\n", SDL_GetError());    
        exit(1);
    }

	DrawSineCurve(screen, 250);
	
    // Wait for ctrl-c from user
    done = 0;
    while (done == 0) {
        while (SDL_PollEvent(&event)) {
            switch (event.type) {
            case SDL_QUIT:
                done = 1;
                break;  
            }           
        }
    }   
    
    SDL_Quit();
    
    return 0;
}
